plugins {
    alias(libs.plugins.android.application) apply false

    id("com.google.gms.google-services") version "4.4.1" apply false


    id("androidx.navigation.safeargs.kotlin") version "2.9.8" apply false
}