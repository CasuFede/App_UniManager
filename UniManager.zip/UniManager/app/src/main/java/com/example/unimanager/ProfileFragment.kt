package com.example.unimanager

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.firebase.ui.auth.AuthUI
import com.google.firebase.auth.FirebaseAuth

class ProfileFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_profile, container, false)

        val user = FirebaseAuth.getInstance().currentUser

       view.findViewById<TextView>(R.id.tv_user_name).text = user?.displayName ?: "Studente"
        view.findViewById<TextView>(R.id.tv_user_email).text = user?.email ?: "Nessuna email"

        view.findViewById<Button>(R.id.btn_logout).setOnClickListener {
            AuthUI.getInstance()
                .signOut(requireContext())
                .addOnCompleteListener {
                    findNavController().navigate(R.id.action_profileFragment_to_loginFragment)
                }
        }


        val sharedPrefs = requireActivity().getSharedPreferences("UniManagerPrefs", android.content.Context.MODE_PRIVATE)
        val rgDegreeType = view.findViewById<android.widget.RadioGroup>(R.id.rg_degree_type)

        when (sharedPrefs.getInt("TARGET_CFU", 180)) {
            180 -> rgDegreeType.check(R.id.rb_triennale)
            120 -> rgDegreeType.check(R.id.rb_magistrale)
            300 -> rgDegreeType.check(R.id.rb_ciclo_unico)
        }

        rgDegreeType.setOnCheckedChangeListener { _, checkedId ->
            val editor = sharedPrefs.edit()
            when (checkedId) {
                R.id.rb_triennale -> {
                    editor.putInt("TARGET_CFU", 180)
                    editor.putString("DEGREE_NAME", "Triennale")
                }
                R.id.rb_magistrale -> {
                    editor.putInt("TARGET_CFU", 120)
                    editor.putString("DEGREE_NAME", "Magistrale")
                }
                R.id.rb_ciclo_unico -> {
                    editor.putInt("TARGET_CFU", 300)
                    editor.putString("DEGREE_NAME", "Ciclo Unico")
                }
            }
            editor.apply()
            UIHelper.showSuccess(view, "Obiettivo carriera aggiornato!")
        }

        return view
    }
}