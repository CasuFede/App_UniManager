package com.example.unimanager

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.unimanager.databinding.FragmentDashboardBinding

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    private val viewModel: DashboardViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)

        binding.btnSimulator.setOnClickListener {
            openSimulatorDialog()
        }

        val prefs = requireActivity().getSharedPreferences("UniManagerPrefs", android.content.Context.MODE_PRIVATE)
        val targetCfu = prefs.getInt("TARGET_CFU", 180)
        val degreeName = prefs.getString("DEGREE_NAME", "Triennale") ?: "Triennale"

        binding.tvProgressLabel.text = "Progresso $degreeName ($targetCfu CFU)"
        binding.progressCfu.max = targetCfu

        viewModel.setTipoLaurea(degreeName)

        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        binding.recyclerExams.layoutManager = LinearLayoutManager(context)

        val adapter = ExamAdapter { examCliccato ->
            val action = DashboardFragmentDirections.actionDashboardFragmentToAddEditExamFragment(
                tipoLaurea = viewModel.currentTipoLaurea,
                examId = examCliccato.id
            )

            findNavController().navigate(action)
        }

        binding.recyclerExams.adapter = adapter

        binding.chipGroupFilter.setOnCheckedStateChangeListener { group, checkedIds ->
            when (checkedIds.firstOrNull()) {
                R.id.chip_all -> viewModel.applyFilterStatus("TUTTI")
                R.id.chip_passed -> viewModel.applyFilterStatus("SUPERATI")
                R.id.chip_todo -> viewModel.applyFilterStatus("DA_SOSTENERE")
            }
        }



        val swipeHandler = object : androidx.recyclerview.widget.ItemTouchHelper.SimpleCallback(
            0,
            androidx.recyclerview.widget.ItemTouchHelper.LEFT or androidx.recyclerview.widget.ItemTouchHelper.RIGHT
        ) {
            override fun onMove(
                recyclerView: androidx.recyclerview.widget.RecyclerView,
                viewHolder: androidx.recyclerview.widget.RecyclerView.ViewHolder,
                target: androidx.recyclerview.widget.RecyclerView.ViewHolder
            ): Boolean {
                return false
            }

            override fun onSwiped(viewHolder: androidx.recyclerview.widget.RecyclerView.ViewHolder, direction: Int) {

                val position = viewHolder.adapterPosition
                val examToDelete = adapter.currentList[position]
                viewModel.deleteExam(examToDelete.id)

                UIHelper.showDelete(binding.root, "Esame '${examToDelete.nome}' eliminato")
            }

            override fun onChildDraw(
                c: android.graphics.Canvas,
                recyclerView: androidx.recyclerview.widget.RecyclerView,
                viewHolder: androidx.recyclerview.widget.RecyclerView.ViewHolder,
                dX: Float,
                dY: Float,
                actionState: Int,
                isCurrentlyActive: Boolean
            ) {
                val itemView = viewHolder.itemView

                if (dX != 0f) {
                    val background = android.graphics.drawable.GradientDrawable()
                    background.setColor(android.graphics.Color.parseColor("#F44336")) // Rosso

                    val cornerRadius = 8f * itemView.context.resources.displayMetrics.density
                    background.cornerRadius = cornerRadius

                    background.setBounds(itemView.left, itemView.top, itemView.right, itemView.bottom)
                    background.draw(c)

                    val icon = androidx.core.content.ContextCompat.getDrawable(requireContext(), android.R.drawable.ic_menu_delete)
                    icon?.let {
                        it.setTint(android.graphics.Color.WHITE)

                        val iconMargin = (itemView.height - it.intrinsicHeight) / 2
                        val iconTop = itemView.top + (itemView.height - it.intrinsicHeight) / 2
                        val iconBottom = iconTop + it.intrinsicHeight

                        if (dX > 0) {
                            val iconLeft = itemView.left + iconMargin
                            val iconRight = itemView.left + iconMargin + it.intrinsicWidth
                            it.setBounds(iconLeft, iconTop, iconRight, iconBottom)
                        } else {
                            val iconLeft = itemView.right - iconMargin - it.intrinsicWidth
                            val iconRight = itemView.right - iconMargin
                            it.setBounds(iconLeft, iconTop, iconRight, iconBottom)
                        }
                        it.draw(c)
                    }
                }

                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive)
            }
        }

        val itemTouchHelper = androidx.recyclerview.widget.ItemTouchHelper(swipeHandler)
        itemTouchHelper.attachToRecyclerView(binding.recyclerExams)


        viewModel.filteredExams.observe(viewLifecycleOwner) { listaEsami ->
            adapter.submitList(listaEsami)
        }

        binding.fabAddExam.setOnClickListener {
            val action = DashboardFragmentDirections.actionDashboardFragmentToAddEditExamFragment(
                viewModel.currentTipoLaurea,
                null
            )
            findNavController().navigate(action)
        }

        viewModel.mediaVoti.observe(viewLifecycleOwner) { media ->
            binding.tvMedia.text = media
        }
        viewModel.cfuTotali.observe(viewLifecycleOwner) { cfu ->
            binding.tvCfu.text = cfu
            binding.progressCfu.progress = cfu.toIntOrNull() ?: 0
        }

        viewModel.votoLaurea.observe(viewLifecycleOwner) { baseLaurea ->
            binding.tvVotoLaurea.text = baseLaurea
        }

        requireActivity().addMenuProvider(object : androidx.core.view.MenuProvider {
            override fun onCreateMenu(menu: android.view.Menu, menuInflater: android.view.MenuInflater) {
                menuInflater.inflate(R.menu.menu_dashboard, menu)
            }

            override fun onMenuItemSelected(menuItem: android.view.MenuItem): Boolean {
                when (menuItem.itemId) {
                    R.id.action_profile -> {
                        findNavController().navigate(R.id.action_dashboardFragment_to_profileFragment)
                        return true
                    }
                    R.id.action_share -> {
                        val media = viewModel.mediaVoti.value ?: "0.0"
                        val cfu = viewModel.cfuTotali.value ?: "0"
                        val laurea = viewModel.votoLaurea.value ?: "0"

                        val testoDaCondividere = "🎓 Ciao! Ho appena aggiornato il mio libretto su UniManager:\n" +
                                "📚 CFU acquisiti: $cfu\n" +
                                "📊 Media Ponderata: $media\n" +
                                "🎯 Base di Laurea: $laurea\n\n" +
                                "Niente male, eh?"

                        val sendIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(android.content.Intent.EXTRA_TEXT, testoDaCondividere)
                        }

                        val shareIntent = android.content.Intent.createChooser(sendIntent, "Condividi i tuoi successi con...")
                        startActivity(shareIntent)
                        return true
                    }
                }
                return false
            }
        }, viewLifecycleOwner, androidx.lifecycle.Lifecycle.State.RESUMED)

        return binding.root
    }

    private fun openSimulatorDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_simulator, null)
        val containerExams = dialogView.findViewById<android.widget.LinearLayout>(R.id.container_sim_exams)
        val btnAddRow = dialogView.findViewById<android.widget.Button>(R.id.btn_add_sim_row)
        val tvMedia = dialogView.findViewById<android.widget.TextView>(R.id.tv_sim_media)
        val tvLaurea = dialogView.findViewById<android.widget.TextView>(R.id.tv_sim_laurea)

        var currentCfu = 0
        var currentSum = 0.0
        val listaEsamiAttuali = viewModel.filteredExams.value ?: emptyList()
        listaEsamiAttuali.filter { it.superato }.forEach { exam ->
            currentCfu += exam.cfu
            currentSum += (exam.voto * exam.cfu)
        }

        val calculateSimulation = {
            var simCfuTotal = 0
            var simSumTotal = 0.0

            for (i in 0 until containerExams.childCount) {
                val row = containerExams.getChildAt(i)
                val etCfu = row.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_row_cfu)
                val etVoto = row.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_row_voto)

                val cfu = etCfu?.text.toString().toIntOrNull() ?: 0
                val voto = etVoto?.text.toString().toIntOrNull() ?: 0

                if (cfu > 0 && voto in 18..30) {
                    simCfuTotal += cfu
                    simSumTotal += (voto * cfu)
                }
            }

            if (simCfuTotal > 0) {
                val newCfu = currentCfu + simCfuTotal
                val newSum = currentSum + simSumTotal
                val newMedia = newSum / newCfu
                val newLaurea = (newMedia * 110) / 30

                tvMedia.text = String.format("Nuova Media: %.1f", newMedia)
                tvLaurea.text = String.format("Nuova Base Laurea: %.0f", newLaurea)
            } else {
                tvMedia.text = "Nuova Media: --"
                tvLaurea.text = "Nuova Base Laurea: --"
            }
        }

        fun addRow() {
            val rowView = layoutInflater.inflate(R.layout.item_sim_exam, containerExams, false)
            val etCfu = rowView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_row_cfu)
            val etVoto = rowView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_row_voto)

            val textWatcher = object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) { calculateSimulation() }
            }

            etCfu.addTextChangedListener(textWatcher)
            etVoto.addTextChangedListener(textWatcher)

            containerExams.addView(rowView)
        }

        addRow()

        btnAddRow.setOnClickListener {
            addRow()
        }

        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle("🔮 Simulatore Multi-Esame")
            .setView(dialogView)
            .setPositiveButton("Chiudi", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}