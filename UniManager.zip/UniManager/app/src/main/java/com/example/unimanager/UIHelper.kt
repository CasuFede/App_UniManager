package com.example.unimanager // Sostituisci sempre con il tuo package!

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.google.android.material.snackbar.Snackbar

object UIHelper {


    private fun styleSnackbar(snackbar: Snackbar, bgColor: String) {
        val snackbarView = snackbar.view


        val params = snackbarView.layoutParams as ViewGroup.MarginLayoutParams
        params.setMargins(32, 32, 32, 32)
        snackbarView.layoutParams = params


        val background = GradientDrawable()
        background.setColor(Color.parseColor(bgColor))
        background.cornerRadius = 24f // Bordi molto arrotondati
        snackbarView.background = background


        val textView = snackbarView.findViewById<TextView>(com.google.android.material.R.id.snackbar_text)
        textView.setTextColor(Color.WHITE)
        textView.textSize = 15f
        textView.typeface = Typeface.DEFAULT_BOLD
    }


    fun showSuccess(view: View, message: String) {
        val snackbar = Snackbar.make(view, "✨ $message", Snackbar.LENGTH_LONG)
        styleSnackbar(snackbar, "#2E7D32")
        snackbar.show()
    }


    fun showError(view: View, message: String) {
        val snackbar = Snackbar.make(view, "⚠️ $message", Snackbar.LENGTH_LONG)
        styleSnackbar(snackbar, "#D32F2F")
        snackbar.show()
    }


    fun showDelete(view: View, message: String) {
        val snackbar = Snackbar.make(view, "🗑️ $message", Snackbar.LENGTH_LONG)
        styleSnackbar(snackbar, "#455A64")
        snackbar.show()
    }
}