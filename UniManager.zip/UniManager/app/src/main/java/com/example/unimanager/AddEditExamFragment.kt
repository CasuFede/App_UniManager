package com.example.unimanager

import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.unimanager.databinding.FragmentAddEditExamBinding
import kotlin.math.roundToInt

class AddEditExamFragment : Fragment() {
    private var _binding: FragmentAddEditExamBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AddEditExamViewModel by viewModels()
    private val args: AddEditExamFragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddEditExamBinding.inflate(inflater, container, false)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner


        viewModel.tipoLaurea = args.tipoLaurea ?: "Triennale"


        val anniDisponibili = when (viewModel.tipoLaurea.lowercase()) {
            "magistrale" -> listOf("1", "2")
            "ciclo unico", "corso unico" -> listOf("1", "2", "3", "4", "5")
            else -> listOf("1", "2", "3")
        }

        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, anniDisponibili)
        binding.dropdownAnno.setAdapter(adapter)


        binding.dropdownAnno.setOnItemClickListener { parent, _, position, _ ->
            viewModel.anno.value = parent.getItemAtPosition(position).toString()
        }


        binding.dropdownAnno.setText(viewModel.anno.value, false)

        val examIdToEdit = args.examId
        if (examIdToEdit != null) {
            viewModel.loadExam(examIdToEdit)
            binding.btnSave.text = "Aggiorna Esame"
        }

        viewModel.isComposto.observe(viewLifecycleOwner) { ricalcolaMediaInDiretta() }
        viewModel.listaModuli.observe(viewLifecycleOwner) { moduli ->
            aggiornaInterfacciaModuli(moduli)
            ricalcolaMediaInDiretta()
        }

        binding.btnAggiungiModulo?.setOnClickListener {
            val currentList = viewModel.listaModuli.value ?: mutableListOf()
            currentList.add(Modulo(nome = "", cfu = null, voto = null, superato = false))
            viewModel.listaModuli.value = currentList
        }


        binding.btnSave.setOnClickListener {
            if (viewModel.nome.value.isNullOrBlank()) {
                UIHelper.showError(binding.root, "Inserisci il nome dell'esame!")
                return@setOnClickListener
            }

            if (viewModel.anno.value.isNullOrBlank()) {
                UIHelper.showError(binding.root, "Seleziona l'anno di corso!")
                return@setOnClickListener
            }

            val cfuInt = viewModel.cfu.value?.toIntOrNull()
            if (cfuInt == null || cfuInt <= 0) {
                UIHelper.showError(binding.root, "I CFU totali sono obbligatori!")
                return@setOnClickListener
            }


            if (cfuInt > 15) {
                UIHelper.showError(binding.root, "Un singolo esame può avere al massimo 15 CFU!")
                return@setOnClickListener
            }


            if (viewModel.isComposto.value != true) {
                if (viewModel.superato.value == true) {
                    val votoFinale = viewModel.voto.value?.toIntOrNull()
                    if (votoFinale == null || votoFinale !in 18..31) {
                        UIHelper.showError(binding.root, "Inserisci un voto finale valido (tra 18 e 31)!")
                        return@setOnClickListener
                    }
                }
            }


            if (viewModel.isComposto.value == true) {
                val moduli = viewModel.listaModuli.value ?: emptyList()
                if (moduli.isEmpty()) {
                    UIHelper.showError(binding.root, "Aggiungi almeno un modulo!")
                    return@setOnClickListener
                }

                var sommaCfuModuli = 0
                var moduliSuperati = 0
                var sommaVotiPesati = 0.0

                for (modulo in moduli) {

                    if (modulo.nome.isBlank()) {
                        UIHelper.showError(binding.root, "Tutti i moduli devono avere un nome!")
                        return@setOnClickListener
                    }

                    val modCfu = modulo.cfu ?: 0
                    sommaCfuModuli += modCfu

                    val modVoto = modulo.voto
                    if (modVoto != null) {
                        if (modVoto !in 18..31) {
                            UIHelper.showError(binding.root, "Il voto del modulo '${modulo.nome}' deve essere compreso tra 18 e 31!")
                            return@setOnClickListener
                        }

                        moduliSuperati++
                        val votoPerMedia = if (modVoto > 30) 30 else modVoto
                        sommaVotiPesati += (votoPerMedia * modCfu)
                    }
                }

                if (sommaCfuModuli != cfuInt) {
                    UIHelper.showError(binding.root, "I CFU dei moduli ($sommaCfuModuli) non coincidono con i CFU totali ($cfuInt)!")
                    return@setOnClickListener
                }

                viewModel.moduliTotali.value = moduli.size.toString()
                viewModel.moduliSuperati.value = moduliSuperati.toString()

                if (moduliSuperati == moduli.size && moduli.isNotEmpty()) {
                    viewModel.superato.value = true
                    viewModel.voto.value = (sommaVotiPesati / sommaCfuModuli).roundToInt().toString()
                } else {
                    viewModel.superato.value = false
                    viewModel.voto.value = "0"
                }
            } else {
                viewModel.moduliTotali.value = "1"
                viewModel.moduliSuperati.value = if (viewModel.superato.value == true) "1" else "0"
            }

            viewModel.saveExam(examIdToEdit)
        }

        viewModel.saveCompleted.observe(viewLifecycleOwner) { isCompleted ->
            if (isCompleted) {
                UIHelper.showSuccess(binding.root, "Esame salvato con successo!")
                findNavController().navigateUp()
            }
        }
        return binding.root
    }

    private fun ricalcolaMediaInDiretta() {
        if (viewModel.isComposto.value != true) {
            binding.tvMediaModuli?.visibility = View.GONE
            return
        }

        val moduli = viewModel.listaModuli.value ?: emptyList()
        if (moduli.isEmpty()) {
            binding.tvMediaModuli?.visibility = View.GONE
            return
        }

        var sommaCfu = 0
        var sommaVotiPesati = 0.0
        var tuttiVotati = true

        for (modulo in moduli) {
            val cfu = modulo.cfu
            val voto = modulo.voto

            if (cfu == null || cfu <= 0 || voto == null || voto < 18) {
                tuttiVotati = false
                break
            }

            sommaCfu += cfu
            val votoPerMedia = if (voto > 30) 30 else voto
            sommaVotiPesati += (votoPerMedia * cfu)
        }

        if (tuttiVotati && sommaCfu > 0) {
            val media = (sommaVotiPesati / sommaCfu).roundToInt()
            binding.tvMediaModuli?.text = "Tutti i moduli completati! Media pesata: $media"
            binding.tvMediaModuli?.visibility = View.VISIBLE
        } else {
            binding.tvMediaModuli?.visibility = View.GONE
        }
    }

    private fun aggiornaInterfacciaModuli(moduli: List<Modulo>) {
        val container = binding.layoutListaModuli ?: return
        container.removeAllViews()

        for (i in moduli.indices) {
            val modulo = moduli[i]

            val rowLayout = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, 0, 0, 16) }
            }

            val etNome = EditText(requireContext()).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f)
                hint = "Nome mod. ${i + 1}"
                setText(modulo.nome)
                addTextChangedListener { text -> modulo.nome = text.toString() }
            }

            val etCfu = EditText(requireContext()).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                hint = "CFU"
                inputType = InputType.TYPE_CLASS_NUMBER
                setText(modulo.cfu?.toString() ?: "")
                addTextChangedListener { text ->
                    modulo.cfu = text.toString().toIntOrNull()
                    ricalcolaMediaInDiretta()
                }
            }

            val etVoto = EditText(requireContext()).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                hint = "Voto"
                inputType = InputType.TYPE_CLASS_NUMBER
                setText(modulo.voto?.toString() ?: "")
                addTextChangedListener { text ->
                    modulo.voto = text.toString().toIntOrNull()
                    ricalcolaMediaInDiretta()
                }
            }

            val btnRemove = Button(requireContext(), null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = "X"
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                setOnClickListener {
                    val currentList = viewModel.listaModuli.value ?: mutableListOf()
                    currentList.removeAt(i)
                    viewModel.listaModuli.value = currentList
                }
            }

            rowLayout.addView(etNome)
            rowLayout.addView(etCfu)
            rowLayout.addView(etVoto)
            rowLayout.addView(btnRemove)
            container.addView(rowLayout)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}