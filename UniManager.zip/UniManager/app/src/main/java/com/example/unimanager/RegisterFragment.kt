package com.example.unimanager

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.firebase.auth.FirebaseAuth
import com.example.unimanager.databinding.FragmentRegisterBinding

class RegisterFragment : Fragment() {

    private var _binding: FragmentRegisterBinding? = null
    private val binding get() = _binding!!
    private val auth = FirebaseAuth.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRegisterBinding.inflate(inflater, container, false)

        binding.btnRegister.setOnClickListener {
            val email = binding.etEmail.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()
            val confirm = binding.etConfirmPassword.text.toString().trim()


            if (email.isEmpty() || password.isEmpty()) {
                UIHelper.showError(binding.root, "Compila tutti i campi!")
                return@setOnClickListener
            }
            if (password.length < 6) {
                UIHelper.showError(binding.root, "La password deve avere almeno 6 caratteri")
                return@setOnClickListener
            }
            if (password != confirm) {
                UIHelper.showError(binding.root, "Le password non coincidono!")
                return@setOnClickListener
            }

            auth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener {
                    UIHelper.showSuccess(binding.root, "Account creato con successo! Benvenuto.")
                    findNavController().navigate(R.id.action_registerFragment_to_dashboardFragment)
                }
                .addOnFailureListener { e ->
                    UIHelper.showError(binding.root, "Errore di registrazione: ${e.localizedMessage}")
                }
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}