package com.example.unimanager

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class AddEditExamViewModel : ViewModel() {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    val nome = MutableLiveData<String>("")
    val cfu = MutableLiveData<String>("")
    val voto = MutableLiveData<String>("")
    val superato = MutableLiveData<Boolean>(false)
    val anno = MutableLiveData<String>("1")

    val isComposto = MutableLiveData<Boolean>(false)
    val isExistingExam = MutableLiveData<Boolean>(false)

    val moduliTotali = MutableLiveData<String>("1")
    val moduliSuperati = MutableLiveData<String>("0")
    var tipoLaurea: String = "Triennale"

    val listaModuli = MutableLiveData<MutableList<Modulo>>(mutableListOf())

    private val _saveCompleted = MutableLiveData<Boolean>()
    val saveCompleted: LiveData<Boolean> get() = _saveCompleted

    fun loadExam(examId: String) {
        val userId = auth.currentUser?.uid ?: return
        db.collection("users").document(userId).collection("exams").document(examId)
            .get()
            .addOnSuccessListener { doc ->
                if (doc.exists()) {
                    val exam = doc.toObject(Exam::class.java)
                    if (exam != null) {
                        nome.value = exam.nome
                        cfu.value = if (exam.cfu > 0) exam.cfu.toString() else ""
                        voto.value = if (exam.voto > 0) exam.voto.toString() else ""
                        superato.value = exam.superato
                        anno.value = exam.anno.toString()

                        isComposto.value = doc.getBoolean("isComposto") ?: exam.isComposto

                        isExistingExam.value = true // Lo stiamo modificando
                        moduliTotali.value = exam.moduliTotali.toString()
                        moduliSuperati.value = exam.moduliSuperati.toString()
                        tipoLaurea = exam.tipoLaurea
                        listaModuli.value = exam.listaModuli.toMutableList()
                    }
                }
            }
    }

    fun saveExam(examId: String?) {
        val userId = auth.currentUser?.uid ?: return

        val votoFinale = if (superato.value == true) (voto.value?.toIntOrNull() ?: 0) else 0

        val examData = hashMapOf(
            "nome" to (nome.value ?: ""),
            "cfu" to (cfu.value?.toIntOrNull() ?: 0),
            "voto" to votoFinale,
            "superato" to (superato.value ?: false),
            "anno" to (anno.value?.toIntOrNull() ?: 1),
            "isComposto" to (isComposto.value ?: false),
            "moduliTotali" to (moduliTotali.value?.toIntOrNull() ?: 1),
            "moduliSuperati" to (moduliSuperati.value?.toIntOrNull() ?: 0),
            "tipoLaurea" to tipoLaurea,
            "dataSostenimento" to System.currentTimeMillis(),
            // Salva la lista dei moduli su Firebase!
            "listaModuli" to (listaModuli.value ?: emptyList<Modulo>())
        )

        val collectionRef = db.collection("users").document(userId).collection("exams")

        if (examId != null) {
            collectionRef.document(examId).set(examData).addOnSuccessListener { _saveCompleted.value = true }
        } else {
            collectionRef.add(examData).addOnSuccessListener { _saveCompleted.value = true }
        }
    }
}