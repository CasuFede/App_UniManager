package com.example.unimanager

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class DashboardViewModel : ViewModel() {
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    private var allExams = listOf<Exam>()
    private val _filteredExams = MutableLiveData<List<Exam>>()
    val filteredExams: LiveData<List<Exam>> get() = _filteredExams

    // Filtri correnti
    private var currentFilter = "TUTTI"
    var currentTipoLaurea = "Triennale" // Di default

    val mediaVoti = MutableLiveData<String>("0.0")
    val cfuTotali = MutableLiveData<String>("0")
    val votoLaurea = MutableLiveData<String>("0")

    init {
        loadExams()
    }

    private fun loadExams() {
        val userId = auth.currentUser?.uid ?: return
        db.collection("users").document(userId).collection("exams")
            .addSnapshotListener { snapshot, e ->
                if (e != null) return@addSnapshotListener
                if (snapshot != null) {
                    val examList = mutableListOf<Exam>()
                    for (doc in snapshot) {
                        val exam = doc.toObject(Exam::class.java)
                        exam.id = doc.id
                        examList.add(exam)
                    }
                    allExams = examList
                    applyFilters()
                }
            }
    }

    fun setTipoLaurea(tipo: String) {
        currentTipoLaurea = tipo
        applyFilters()
    }

    fun applyFilterStatus(filter: String) {
        currentFilter = filter
        applyFilters()
    }

    private fun applyFilters() {
        var filteredList = allExams.filter { it.tipoLaurea == currentTipoLaurea }

        var totalCfu = 0
        var weightedSum = 0.0

        filteredList.forEach { exam ->
            val isVeramenteSuperato = exam.superato && (!exam.isComposto || exam.moduliSuperati == exam.moduliTotali)

            if (isVeramenteSuperato) {
                totalCfu += exam.cfu
                val votoCalcolo = if (exam.voto == 31) 30 else exam.voto
                weightedSum += (votoCalcolo * exam.cfu)
            }
        }

        cfuTotali.value = totalCfu.toString()
        if (totalCfu > 0) {
            val media = weightedSum / totalCfu
            mediaVoti.value = String.format("%.1f", media)
            votoLaurea.value = String.format("%.0f", (media * 110) / 30)
        } else {
            mediaVoti.value = "0.0"
            votoLaurea.value = "0"
        }

        filteredList = when (currentFilter) {
            "SUPERATI" -> filteredList.filter { it.superato && (!it.isComposto || it.moduliSuperati == it.moduliTotali) }
            "DA_SOSTENERE" -> filteredList.filter { !it.superato || (it.isComposto && it.moduliSuperati < it.moduliTotali) }
            else -> filteredList
        }

        _filteredExams.value = filteredList.sortedWith(
            compareBy<Exam> { it.anno }
                .thenBy { !it.superato }
                .thenBy { it.nome }
        )
    }

    fun deleteExam(examId: String) {
        val userId = auth.currentUser?.uid ?: return
        db.collection("users").document(userId).collection("exams").document(examId).delete()
    }
}