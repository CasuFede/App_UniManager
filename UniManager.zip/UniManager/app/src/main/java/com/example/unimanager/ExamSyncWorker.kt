package com.example.unimanager

import android.content.Context
import android.util.Log
import androidx.work.Worker
import androidx.work.WorkerParameters

class ExamSyncWorker(context: Context, workerParams: WorkerParameters) :
    Worker(context, workerParams) {

     override fun doWork(): Result {
        Log.d("ExamSyncWorker", "Avvio del task in background...")

        try {
            Thread.sleep(2000)

            NotificationHelper.showNotification(
                applicationContext,
                "UniManager",
                "Sincronizzazione dati completata con successo!"
            )

            Log.d("ExamSyncWorker", "Task completato con successo.")
            return Result.success()

        } catch (e: Exception) {
            Log.e("ExamSyncWorker", "Errore durante il task", e)
            return Result.failure()
        }
    }
}