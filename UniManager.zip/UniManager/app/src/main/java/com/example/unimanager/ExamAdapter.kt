package com.example.unimanager

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.unimanager.databinding.ItemExamBinding

class ExamAdapter(private val onExamClick: (Exam) -> Unit) :
    ListAdapter<Exam, ExamAdapter.ExamViewHolder>(DiffCallback) {

    class ExamViewHolder(private val binding: ItemExamBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(exam: Exam, onExamClick: (Exam) -> Unit) {
            binding.exam = exam
            binding.executePendingBindings()

            binding.root.setOnClickListener {
                onExamClick(exam)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExamViewHolder {
        val binding = ItemExamBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ExamViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ExamViewHolder, position: Int) {
        val currentExam = getItem(position)
        holder.bind(currentExam, onExamClick)
    }

    companion object DiffCallback : DiffUtil.ItemCallback<Exam>() {
        override fun areItemsTheSame(oldItem: Exam, newItem: Exam): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Exam, newItem: Exam): Boolean {
            return oldItem == newItem
        }
    }
}