package com.example.unimanager

import com.google.firebase.firestore.PropertyName

data class Exam(
    var id: String = "",
    var nome: String = "",
    var cfu: Int = 0,
    var voto: Int = 0,
    var superato: Boolean = false,
    var dataSostenimento: Long = System.currentTimeMillis(),

    var anno: Int = 1,

    @get:PropertyName("isComposto")
    @set:PropertyName("isComposto")
    var isComposto: Boolean = false,

    var moduliTotali: Int = 1,
    var moduliSuperati: Int = 0,
    var tipoLaurea: String = "Triennale",
    var listaModuli: List<Modulo> = emptyList()
)