package com.example.unimanager

data class Modulo(
    val id: String = java.util.UUID.randomUUID().toString(),
    var nome: String = "",
    var voto: Int? = null,
    var cfu: Int? = null,
    var superato: Boolean = false
)